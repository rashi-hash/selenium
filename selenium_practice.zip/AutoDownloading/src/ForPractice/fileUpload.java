package ForPractice;

import java.io.IOException;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class fileUpload {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://altoconvertpdftojpg.com/");
		 driver.manage().window().maximize();
		driver.findElement(By.xpath("(//button[@id='browse'])[1]")).click();
	    Thread.sleep(2000);
		
		Runtime.getRuntime().exec("C:\\Users\\Rashi\\OneDrive\\Desktop\\UPLOADING FILE\\fileUpload.exe");
		
//		JavascriptExecutor js =(JavascriptExecutor) driver;
//			 js.executeScript("arguments[0].click();",driver.findElement(By.xpath("//button[@id='submit_btn']")) );
		Thread.sleep(2000L);
		driver.findElement(By.xpath("//button[@id='submit_btn']")).sendKeys(Keys.ENTER);
		
		
			
	}

}
