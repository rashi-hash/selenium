package rashiseleniumT.AbstractComponents;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import rashiseleniumT.pageobjects.CartPage;
import rashiseleniumT.pageobjects.OrderPage;

public class AbstractComponent 
{  
	WebDriver driver;
	public AbstractComponent(WebDriver driver) 
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy (xpath="//button[@routerlink='/dashboard/cart']")
	WebElement cartheader;
	
	@FindBy(xpath="//button[@routerlink='/dashboard/myorders']")
	WebElement orderheader;
	
	
		
	
    public void waitForElementsToAppear(By findBy)
	{
    	WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(4));
    wait.until(ExpectedConditions.visibilityOfElementLocated(findBy));
    }
    
    
    public void waitForWebElementsToAppear(WebElement findBy)
   	{
       	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(4));
       wait.until(ExpectedConditions.visibilityOf(findBy));
       }

    public void waitForElementsToDisappear(WebElement element) { 
    	
    	
    	WebDriverWait wait=new WebDriverWait(driver,Duration.ofSeconds(5));
    	 wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.cssSelector(".ng-animating"))));

    }
    public  CartPage goToCartPage() 
    {
    	CartPage cartpage=new CartPage(driver);
        cartheader.click();
        
        return cartpage;

    }
    
    public  OrderPage goToOrderPage() 
    {
    	OrderPage orderpage=new OrderPage(driver);
        orderheader.click();
        
        return orderpage;

    }
}
