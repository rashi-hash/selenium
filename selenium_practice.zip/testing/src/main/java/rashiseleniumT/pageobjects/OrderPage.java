package rashiseleniumT.pageobjects;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import rashiseleniumT.AbstractComponents.AbstractComponent;

public class OrderPage extends AbstractComponent {

	WebDriver driver;

	@FindBy(xpath = "//button[normalize-space()='Checkout']")
	WebElement checkoutEle;
	
	@FindBy(css="tr td:nth-child(3)")
	private List<WebElement> ProductnamesInTable;
	
;
	
	
		
public OrderPage  (WebDriver driver) 
{
			
	
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
		


public Boolean VerifyOrderDisplay(String productName) 
{
	
    Boolean match=ProductnamesInTable.stream().anyMatch(Product->Product.getText().equalsIgnoreCase(productName));
return match;
}



public CheckOutPage goToCheckout() throws InterruptedException 
{	
   JavascriptExecutor js =(JavascriptExecutor) driver;
   js.executeScript("arguments[0].click();",checkoutEle );
   //js.executeScript("arguments[0].scrollIntoView(true);", checkoutElemenent);
   //Thread.sleep(1000);
   //checkoutEle.click();
   //js.executeScript("arguments[0].click();", driver.findElement(By.cssSelector("[routerlink*='cart']")));
   
   return new CheckOutPage(driver);
}


}


