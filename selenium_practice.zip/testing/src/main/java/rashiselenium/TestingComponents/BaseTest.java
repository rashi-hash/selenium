package rashiselenium.TestingComponents;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import java.time.Duration;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import rashiseleniumT.pageobjects.LandingPage;

public class BaseTest {

	public WebDriver driver;
	public LandingPage landingpage;
	public Properties prop;
	public WebDriver initialize() throws IOException 
	
	{
		
		
		
		prop=new Properties();
		String filePath = System.getProperty("user.dir")+"/src/main/java/rashiselenium/TestingComponents/global.properties";// changed location to main class
		FileInputStream fis = new FileInputStream(filePath);
		prop.load(fis);
		
		String browserName=prop.getProperty("browser");
		
		if(browserName.equalsIgnoreCase("chrome")) 
		{    
			ChromeOptions options = new ChromeOptions();
	        options.addArguments("--remote-allow-origins=*");
			driver = new ChromeDriver();
		}
		
		
       
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));

        driver.manage().window().maximize();
        return driver;
	}
	
	
	public List <HashMap<String,String>> getJsonDataToMap(String filepath) throws IOException 
	{
		//reading json to string
		String jsonContent=FileUtils.readFileToString(new File(filepath),StandardCharsets.UTF_8);
	
      //string to hashmap,use jackson databind dependency
	ObjectMapper mapper=new ObjectMapper();
	List <HashMap<String, String> >data=mapper.readValue(jsonContent, new TypeReference< List<HashMap<String,String>>>(){});
	return data;
}
	public String getScreeenShot(String testCaseName,WebDriver driver) throws IOException 
	 {
		 TakesScreenshot ts=(TakesScreenshot)driver;
		 File source=ts.getScreenshotAs(OutputType.FILE);
		 File file=new File(System.getProperty("user.dir")+"//reports//"+testCaseName+".png");
		 FileUtils.copyFile(source, file);
		 return System.clearProperty("user.dir")+"//reports//"+testCaseName+".png";
	 }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@BeforeMethod(alwaysRun=true)
	public LandingPage LaunchApplication() throws IOException 
	{
		driver=initialize();
		landingpage=new LandingPage(driver);
	    landingpage.goTo();
		return landingpage;
	}
	
	
	
@AfterMethod(alwaysRun=true)
	public void TearDown() throws InterruptedException 
	{   
		
		driver.close();
	}
}






















