package rashiselenium.tests;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import rashiselenium.TestingComponents.BaseTest;
import rashiselenium.TestingComponents.Retry;
import rashiseleniumT.pageobjects.CartPage;
import rashiseleniumT.pageobjects.CheckOutPage;
import rashiseleniumT.pageobjects.ConfirmationPage;
import rashiseleniumT.pageobjects.LandingPage;
import rashiseleniumT.pageobjects.ProductCatalogue;

public class ErrorValidationTests extends BaseTest {
    
    	
    	
    	
 	
    	
    	@Test(groups= {"LogIn Handling"},retryAnalyzer=Retry.class)
    	public void LogInErrorValidation() throws IOException,InterruptedException
    	
    	{
        //String productName="ZARA COAT 3";  
      
        
        landingpage.Application("rashi0034s66@gmail.com", "123456s78Rash!");
        
        Assert.assertEquals("Incorrect email or password.",landingpage.getErrorMessage());
                  
        
    	}
    	
    	@Test
    	public void ProductErrorValidation() throws IOException,InterruptedException
    	
    	{
        String productName="ZARA COAT 3";
       
       
        
      
        ProductCatalogue productcatalogue=landingpage.Application("rashi003466@gmail.com", "12345678Rash!");
        
        List<WebElement>products=productcatalogue.goToProductList();
        productcatalogue.addProductToCart(productName);
        CartPage cartpage=productcatalogue.goToCartPage();
        
        Boolean match=cartpage.VerifyProducDisplay("ZARA COAT 33");
                
       
        
        Assert.assertFalse(match);
//        Thread.sleep(1000);
      
        
        
        
        
        
        
        
    	}
    
}
         
         
         
        
   
         
         
         




