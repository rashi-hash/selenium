package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowActivities {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rashi\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://google.com");
		Thread.sleep(1000L);
		driver.navigate().to("https://rahulshettyacademy.com");
		Thread.sleep(10000L);
		driver.navigate().back();
		Thread.sleep(10000L);
		driver.navigate().forward();
		
		

	}

}
