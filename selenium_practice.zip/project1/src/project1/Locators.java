package project1;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Locators {

	public static void main(String[] args) throws InterruptedException {
		// locators
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rashi\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));//so that it waits for the error msg to show up
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
        driver.findElement(By.id("inputUsername")).sendKeys("rahul");
        driver.findElement(By.name("inputPassword")).sendKeys("hello123");
        driver.findElement(By.className("signInBtn")).click();//two classes sign in and submit,anyone can do
        
        System.out.println(driver.findElement(By.cssSelector("p.error")).getText());
        driver.findElement(By.linkText("Forgot your password?")).click();
        Thread.sleep(1000L);
        driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("john");
        //driver.findElement(By.cssSelector("input[placeholer='Email']")).sendKeys("john@rsa.com");
        //driver.findElement(By.xpath("//input[@type='text'][2]")).clear();
        driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("john@gmail.com");//prblm
        driver.findElement(By.xpath("//input[@placeholder='Phone Number']")).sendKeys("1234567");
        driver.findElement(By.className("reset-pwd-btn")).click();
          
        System.out.println(driver.findElement(By.cssSelector(".infoMsg")).getText());
        driver.findElement(By.xpath("//button[@class='go-to-login-btn']")).click();
        Thread.sleep(1000L);
        driver.findElement(By.xpath("//input[@id='inputUsername']")).sendKeys("rahul");
        
        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("rahulshettyacademy");
        driver.findElement(By.xpath("//input[@id='chkboxOne']")).click();
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(1000L);
        System.out.println(driver.findElement(By.cssSelector("div[class='login-container'] p")).getText());
        Thread.sleep(1000L);       
       
        driver.findElement(By.xpath("//button[@class='logout-btn']")).click();
        //driver.close();
        
        
        
        
        
        
	}

}
