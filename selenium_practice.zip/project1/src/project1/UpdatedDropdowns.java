package project1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class UpdatedDropdowns {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rashi\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/dropdownsPractise/");
	    driver.findElement(By.id("divpaxinfo")).click();
	    Thread.sleep(1000L);
	    int i=1;
	    while(i<5) {
	    driver.findElement(By.id("hrefIncAdt")).click();
	    i++;
	    }
	    
	    driver.findElement(By.id("btnclosepaxoption")).click();
	    
	    //destination
	    //WebElement destn=driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT"));
	    //Select dtn= new Select(destn);
	    //dtn.selectByVisibleText("Goa (GOI)");
	    //System.out.println(dtn.getFirstSelectedOption().getText());
	    //Thread.sleep(1000L);
	    
	    driver.findElement(By.id("")).click();
		
		

	}

}
