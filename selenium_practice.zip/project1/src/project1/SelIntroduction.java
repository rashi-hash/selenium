package project1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
public class SelIntroduction {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		//ChromeDriver driver=new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Rashi\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		
		
		
		//firefox launch
		//geckodriver~chromedriver
		//System.setProperty("webdriver.gecko.driver", "C:\\Users\\Rashi\\Downloads\\geckodriver-v0.33.0-win64\\geckodriver.exe");
		//WebDriver driver=new FirefoxDriver();
		//driver.get("https://firefox.com");
		
		
		
		
		
		
		//driver.get("https://rahulshettyacademy.com");
		//System.out.println(driver.getTitle());
		//System.out.println(driver.getCurrentUrl());
		//driver.close();//closes current tab/window
		//driver.quit();//closes every associated window
	}

}
