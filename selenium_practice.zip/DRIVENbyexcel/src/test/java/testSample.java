import java.io.IOException;
import java.util.ArrayList;

public class testSample {

	public static void main(String[] args) throws IOException {
		
     testDatawithExcel data=new testDatawithExcel();
     ArrayList<String> DATA=data.getDATA("Add Profile");
     System.out.println(DATA.get(0));
     System.out.println(DATA.get(1));
     System.out.println(DATA.get(2));
     
     
     
     
	}

	
	

}
